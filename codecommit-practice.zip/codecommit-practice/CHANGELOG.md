# Changelog

## [Unreleased]
- Pagination support for /tasks endpoint
- Notification hooks on task events

## [1.0.0] - 2024-01-01
### Added
- Initial release of TaskFlow API
- CRUD endpoints: GET/POST/PUT/DELETE /tasks
- Health check endpoint: GET /health
- Stats endpoint: GET /stats
- In-memory task store
- Status filter on GET /tasks
- Priority field (low / medium / high)
