"""
TaskFlow API - Dummy App for AWS CodeCommit Practice
A simple task management REST API built with Flask.
"""

from flask import Flask, jsonify, request
from datetime import datetime
import uuid

app = Flask(__name__)

# In-memory task store (intentionally simple — no DB needed)
TASKS = {}

# ── Health Check ──────────────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "service": "taskflow-api",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat()
    })

# ── Tasks CRUD ────────────────────────────────────────────────────────────────

@app.route("/tasks", methods=["GET"])
def get_tasks():
    """Return all tasks, optionally filtered by status."""
    status_filter = request.args.get("status")
    tasks = list(TASKS.values())
    if status_filter:
        tasks = [t for t in tasks if t["status"] == status_filter]
    return jsonify({"tasks": tasks, "count": len(tasks)})


@app.route("/tasks/<task_id>", methods=["GET"])
def get_task(task_id):
    """Return a single task by ID."""
    task = TASKS.get(task_id)
    if not task:
        return jsonify({"error": f"Task '{task_id}' not found"}), 404
    return jsonify(task)


@app.route("/tasks", methods=["POST"])
def create_task():
    """Create a new task."""
    data = request.get_json()
    if not data or not data.get("title"):
        return jsonify({"error": "title is required"}), 400

    task_id = str(uuid.uuid4())[:8]
    task = {
        "id": task_id,
        "title": data["title"],
        "description": data.get("description", ""),
        "status": "todo",
        "priority": data.get("priority", "medium"),
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat(),
    }
    TASKS[task_id] = task
    return jsonify(task), 201


@app.route("/tasks/<task_id>", methods=["PUT"])
def update_task(task_id):
    """Update task status or details."""
    task = TASKS.get(task_id)
    if not task:
        return jsonify({"error": f"Task '{task_id}' not found"}), 404

    data = request.get_json()
    allowed_fields = {"title", "description", "status", "priority"}
    for field in allowed_fields:
        if field in data:
            task[field] = data[field]
    task["updated_at"] = datetime.utcnow().isoformat()
    return jsonify(task)


@app.route("/tasks/<task_id>", methods=["DELETE"])
def delete_task(task_id):
    """Delete a task."""
    task = TASKS.pop(task_id, None)
    if not task:
        return jsonify({"error": f"Task '{task_id}' not found"}), 404
    return jsonify({"message": f"Task '{task_id}' deleted"}), 200


# ── Stats ─────────────────────────────────────────────────────────────────────

@app.route("/stats", methods=["GET"])
def stats():
    """Return task statistics."""
    all_tasks = list(TASKS.values())
    return jsonify({
        "total": len(all_tasks),
        "by_status": {
            "todo":        sum(1 for t in all_tasks if t["status"] == "todo"),
            "in_progress": sum(1 for t in all_tasks if t["status"] == "in_progress"),
            "done":        sum(1 for t in all_tasks if t["status"] == "done"),
        },
        "by_priority": {
            "high":   sum(1 for t in all_tasks if t["priority"] == "high"),
            "medium": sum(1 for t in all_tasks if t["priority"] == "medium"),
            "low":    sum(1 for t in all_tasks if t["priority"] == "low"),
        }
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
