"""
Application configuration — loaded from environment variables.
Defaults are safe for local development.
"""

import os


class Config:
    APP_NAME    = os.getenv("APP_NAME", "taskflow-api")
    ENV         = os.getenv("ENV", "development")
    PORT        = int(os.getenv("PORT", 5000))
    DEBUG       = os.getenv("DEBUG", "true").lower() == "true"
    LOG_LEVEL   = os.getenv("LOG_LEVEL", "INFO")
    MAX_TASKS   = int(os.getenv("MAX_TASKS", 1000))
    API_VERSION = "v1"

    # Feature flags — toggle without code change
    FEATURE_STATS    = os.getenv("FEATURE_STATS", "true").lower() == "true"
    FEATURE_PRIORITY = os.getenv("FEATURE_PRIORITY", "true").lower() == "true"

    def __repr__(self):
        return f"<Config env={self.ENV} port={self.PORT}>"
