"""
notifications.py  — intentionally has 3 bugs for branch/PR practice.

EXERCISE: Create a branch called 'fix/notifications', fix the bugs,
          push the branch, and raise a Pull Request in CodeCommit.

BUG 1  (line 23)  : wrong default level passed to _log()
BUG 2  (line 37)  : missing return statement
BUG 3  (line 51)  : typo in dict key ("messge" instead of "message")
"""


class Notifier:
    """Simple in-memory notification logger."""

    def __init__(self):
        self.history = []

    def _log(self, level: str, message: str) -> dict:
        entry = {"level": level, "message": message}
        self.history.append(entry)
        return entry

    # BUG 1: should pass level="info", not level="debug"
    def notify_task_created(self, task_id: str) -> dict:
        return self._log(level="debug", message=f"Task {task_id} created")

    # BUG 2: missing return — caller gets None instead of the log entry
    def notify_task_completed(self, task_id: str):
        self._log(level="info", message=f"Task {task_id} marked done")

    # BUG 3: key typo "messge" — JSON consumers will silently get wrong key
    def notify_task_deleted(self, task_id: str) -> dict:
        entry = {"level": "warn", "messge": f"Task {task_id} deleted"}
        self.history.append(entry)
        return entry

    def get_history(self) -> list:
        return list(self.history)

    def clear(self):
        self.history.clear()
