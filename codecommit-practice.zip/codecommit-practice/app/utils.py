"""
Utility helpers for TaskFlow API.
"""

from datetime import datetime


VALID_STATUSES   = {"todo", "in_progress", "done"}
VALID_PRIORITIES = {"low", "medium", "high"}


def validate_task_payload(data: dict) -> list:
    """
    Validate incoming task payload.
    Returns a list of error messages (empty list = valid).
    """
    errors = []

    if not data:
        return ["Request body is required"]

    if not data.get("title"):
        errors.append("'title' is required")
    elif len(data["title"]) > 200:
        errors.append("'title' must be 200 characters or fewer")

    if "status" in data and data["status"] not in VALID_STATUSES:
        errors.append(f"'status' must be one of: {sorted(VALID_STATUSES)}")

    if "priority" in data and data["priority"] not in VALID_PRIORITIES:
        errors.append(f"'priority' must be one of: {sorted(VALID_PRIORITIES)}")

    return errors


def format_timestamp(dt: datetime = None) -> str:
    """Return an ISO-8601 UTC timestamp string."""
    return (dt or datetime.utcnow()).strftime("%Y-%m-%dT%H:%M:%SZ")


def paginate(items: list, page: int = 1, per_page: int = 20) -> dict:
    """Simple in-memory paginator."""
    page     = max(1, page)
    per_page = min(100, max(1, per_page))
    start    = (page - 1) * per_page
    end      = start + per_page
    return {
        "items":      items[start:end],
        "page":       page,
        "per_page":   per_page,
        "total":      len(items),
        "total_pages": -(-len(items) // per_page),  # ceiling division
    }
