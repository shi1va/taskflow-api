"""
Unit tests for TaskFlow API.
Run with: pytest tests/
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from app.app import app, TASKS
from app.utils import validate_task_payload, paginate, format_timestamp


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def client():
    app.config["TESTING"] = True
    TASKS.clear()
    with app.test_client() as c:
        yield c
    TASKS.clear()


# ── Health ────────────────────────────────────────────────────────────────────

def test_health_returns_ok(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.get_json()["status"] == "ok"

def test_health_has_version(client):
    r = client.get("/health")
    assert "version" in r.get_json()

# ── Create task ───────────────────────────────────────────────────────────────

def test_create_task_success(client):
    r = client.post("/tasks", json={"title": "Write tests"})
    assert r.status_code == 201
    data = r.get_json()
    assert data["title"] == "Write tests"
    assert data["status"] == "todo"
    assert "id" in data

def test_create_task_missing_title(client):
    r = client.post("/tasks", json={"description": "no title"})
    assert r.status_code == 400

def test_create_task_with_priority(client):
    r = client.post("/tasks", json={"title": "Urgent", "priority": "high"})
    assert r.status_code == 201
    assert r.get_json()["priority"] == "high"

# ── Get tasks ─────────────────────────────────────────────────────────────────

def test_get_all_tasks_empty(client):
    r = client.get("/tasks")
    assert r.status_code == 200
    assert r.get_json()["count"] == 0

def test_get_all_tasks_after_create(client):
    client.post("/tasks", json={"title": "Task A"})
    client.post("/tasks", json={"title": "Task B"})
    r = client.get("/tasks")
    assert r.get_json()["count"] == 2

def test_get_task_by_id(client):
    create_r = client.post("/tasks", json={"title": "Find me"})
    task_id  = create_r.get_json()["id"]
    r        = client.get(f"/tasks/{task_id}")
    assert r.status_code == 200
    assert r.get_json()["title"] == "Find me"

def test_get_task_not_found(client):
    r = client.get("/tasks/doesnotexist")
    assert r.status_code == 404

def test_filter_tasks_by_status(client):
    client.post("/tasks", json={"title": "A"})
    create_r = client.post("/tasks", json={"title": "B"})
    task_id  = create_r.get_json()["id"]
    client.put(f"/tasks/{task_id}", json={"status": "done"})
    r = client.get("/tasks?status=done")
    assert r.get_json()["count"] == 1

# ── Update task ───────────────────────────────────────────────────────────────

def test_update_task_status(client):
    create_r = client.post("/tasks", json={"title": "Progress me"})
    task_id  = create_r.get_json()["id"]
    r        = client.put(f"/tasks/{task_id}", json={"status": "in_progress"})
    assert r.status_code == 200
    assert r.get_json()["status"] == "in_progress"

def test_update_task_not_found(client):
    r = client.put("/tasks/ghost", json={"status": "done"})
    assert r.status_code == 404

# ── Delete task ───────────────────────────────────────────────────────────────

def test_delete_task_success(client):
    create_r = client.post("/tasks", json={"title": "Delete me"})
    task_id  = create_r.get_json()["id"]
    r        = client.delete(f"/tasks/{task_id}")
    assert r.status_code == 200
    assert client.get(f"/tasks/{task_id}").status_code == 404

def test_delete_task_not_found(client):
    r = client.delete("/tasks/phantom")
    assert r.status_code == 404

# ── Stats ─────────────────────────────────────────────────────────────────────

def test_stats_empty(client):
    r = client.get("/stats")
    assert r.status_code == 200
    assert r.get_json()["total"] == 0

def test_stats_counts(client):
    client.post("/tasks", json={"title": "T1", "priority": "high"})
    r1 = client.post("/tasks", json={"title": "T2", "priority": "low"})
    client.put(f"/tasks/{r1.get_json()['id']}", json={"status": "done"})
    data = client.get("/stats").get_json()
    assert data["total"] == 2
    assert data["by_status"]["done"] == 1
    assert data["by_priority"]["high"] == 1

# ── Utils ─────────────────────────────────────────────────────────────────────

def test_validate_valid_payload():
    assert validate_task_payload({"title": "Valid"}) == []

def test_validate_missing_title():
    errors = validate_task_payload({})
    assert any("title" in e for e in errors)

def test_validate_bad_status():
    errors = validate_task_payload({"title": "X", "status": "flying"})
    assert any("status" in e for e in errors)

def test_validate_bad_priority():
    errors = validate_task_payload({"title": "X", "priority": "nuclear"})
    assert any("priority" in e for e in errors)

def test_paginate_basic():
    items = list(range(25))
    result = paginate(items, page=1, per_page=10)
    assert len(result["items"]) == 10
    assert result["total"] == 25
    assert result["total_pages"] == 3

def test_format_timestamp_returns_string():
    ts = format_timestamp()
    assert isinstance(ts, str)
    assert "T" in ts
